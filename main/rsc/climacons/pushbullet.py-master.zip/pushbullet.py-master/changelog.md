# Changelog

- 0.4.1

   - Fix installation, update the API url.

- 0.4.0

    - API changes, direct access to the device object.

- 0.3.0

	- Add list style access to devices.

- 0.2.1

	- Updated documentation, no code changes.

- 0.2.0

	- Add support for file uploads.

- 0.1.1

	- Fix for error during installation.

- 0.1.0

	- Initial version.
